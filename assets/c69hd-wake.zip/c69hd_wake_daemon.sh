#!/system/bin/sh
# Onyx Boox C69HD Hardware Button Wake Daemon
# Running as background service via Magisk

DAEMON_LOG="/data/local/tmp/c69hd_wake.log"
echo "=== C69HD Button Wake Daemon started: $(date) ===" > "$DAEMON_LOG"

# Function to wake screen if asleep
wake_device() {
    reason="$1"
    if ! dumpsys power | grep -q 'mWakefulness=Awake'; then
        echo "[WAKE] Screen is asleep. Waking via $reason at $(date)" >> "$DAEMON_LOG"
        sendevent /dev/input/event0 1 116 1
        sendevent /dev/input/event0 0 0 0
        sendevent /dev/input/event0 1 116 0
        sendevent /dev/input/event0 0 0 0
    else
        echo "[IGNORE] Event ($reason) received but screen is already awake." >> "$DAEMON_LOG"
    fi
}

# Worker 1: Monitor physical center button on /dev/input/event0 (scancode 158 / 0x9e)
monitor_center_button() {
    getevent /dev/input/event0 | while read -r line; do
        case "$line" in
            *"0001 009e 00000001"*)
                wake_device "CenterButton(158)"
                ;;
        esac
    done
}

# Worker 2: Monitor physical side page-turn buttons on /dev/input/event3 (scancodes 104 / 109)
monitor_side_buttons() {
    if [ -e /dev/input/event3 ]; then
        getevent /dev/input/event3 | while read -r line; do
            case "$line" in
                *"0001 0068 00000001"*|*"0001 006d 00000001"*)
                    wake_device "SideButton"
                    ;;
            esac
        done
    fi
}

# Launch monitors in background
monitor_center_button &
PID_CENTER=$!

monitor_side_buttons &
PID_SIDE=$!

echo "Monitors launched: Center(PID $PID_CENTER), Side(PID $PID_SIDE)" >> "$DAEMON_LOG"

# Wait for children
wait
