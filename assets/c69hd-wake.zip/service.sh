#!/system/bin/sh
MODDIR=${0%/*}

# Wait for boot completion
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 2
done

# Ensure daemon is executable and start it
chmod 755 "$MODDIR/c69hd_wake_daemon.sh"
pkill -f c69hd_wake_daemon.sh 2>/dev/null
pkill -f getevent 2>/dev/null
nohup "$MODDIR/c69hd_wake_daemon.sh" </dev/null >/dev/null 2>&1 &
